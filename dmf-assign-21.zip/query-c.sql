SELECT Readings.SiteID, Stations.Location, AVG(`PM2.5`), AVG(`VPM2.5`) 
FROM `Readings`,`Stations` 
WHERE Readings.SiteID = Stations.SiteID 
AND YEAR(Readings.DateTime) BETWEEN 2010 AND 2019 
AND HOUR(Readings.DateTime) BETWEEN 7 AND 9 
GROUP BY Readings.SiteID;