# Importing necessary modules
import mariadb
import sys
import pandas as pd
import csv
import datetime

# Creating a starting point when this python code starts
start = datetime.datetime.now()


try:
    connmydb = mariadb.connect(              # Establishing connection with mysql server
        user="root",                         # User name 'root'
        password="",                         # No Password 
        host="localhost",
        port=3306,                           # Port = 3306
    )

    mycursor = connmydb.cursor()             # Setting up cursor

    mycursor.execute("DROP DATABASE IF EXISTS `pollution-db2`")       # Dropping any previous database if exists with the name 'pollution-db2'
    mycursor.execute("CREATE DATABASE `pollution-db2` ")              # Creating a database with the name 'pollution-db2'

    mycursor.execute("USE `pollution-db2`")                           # Using the created database

# Creating a table with name 'Readings' and defining colums and their data types
    mycursor.execute(""" 
        CREATE TABLE IF NOT EXISTS `Readings`(                        
            `ReadingID` INT NOT NULL,
            `DateTime` DATETIME NOT NULL,
            `NOx` FLOAT,
            `NO2` FLOAT,
            `NO` FLOAT,
            `PM10` FLOAT,
            `NVPM10` FLOAT,
            `VPM10` FLOAT,
            `NVPM2.5` FLOAT,
            `PM2.5` FLOAT,
            `VPM2.5` FLOAT,
            `CO` FLOAT,
            `O3` FLOAT,
            `SO2` FLOAT,
            `Temperature` REAL,
            `RH` INT,
            `AirPressure` INT,
            `DateStart` DATETIME,
            `DateEnd` DATETIME,
            `Current` TEXT(5),
            `InstrumentType` VARCHAR(32),
            `SiteID` INT NOT NULL,
            PRIMARY KEY (`ReadingiD`))
            ;""")

# Creating a table with name 'Stations' and defining colums and their data types
    mycursor.execute("""
        CREATE TABLE IF NOT EXISTS `Stations`(
            `SiteID` INT NOT NULL,
            `Location` VARCHAR(48) NOT NULL,
            `geo_point_2d` varchar(48) NOT NULL,
            PRIMARY KEY (`SiteID`))
            """)

# Creating a table with name 'Schema' and defining colums and their data types
    mycursor.execute("""     
        CREATE TABLE IF NOT EXISTS `Schema`(
            `SchemaID` INT NOT NULL,
            `Measure` VARCHAR(32) NOT NULL,
            `Description` VARCHAR (64) NOT NULL,
            `Unit` VARCHAR (24) NOT NULL,
            PRIMARY KEY (`SchemaID`))
            """)

# establishing relation between tables by assigning Foreign key and references
    mycursor.execute("ALTER TABLE `Readings` ADD FOREIGN KEY(`SiteID`) REFERENCES `Stations`(`SiteID`)")

# Creating an empty list
    schema_rows = []  

# opening schema.csv as abc and reading all lines and entering in the empty set created
    with open('schema.csv', mode='r', encoding='UTF-8') as abc:
        schema_rows = abc.readlines()

# Defining first line as headers
    schema_headers = schema_rows.pop(0)

# Creating an empty list
    reading = []

# Opening clean.csv in read mode as abc and reading all lines and entering in the empty set created
    with open('clean.csv', mode='r') as abc:
        reading = abc.readlines()

# Defining first line as headers
    reading_head = reading.pop(0)

    schema_table = []              # creating empty list for schema table
    stations_table = set()         # Creating empty set for station table, as it has unique values
    readings_table = []            # Creating epmty list for readings table 

# Iterating through the lines of Schema_rows and entering the values in schema table variable
    for number, line in enumerate(schema_rows):
        entry = line.split(';')
        schema_table.append([number + 1, entry[0], entry[1], entry[2].strip('\n')])

# Iterating through the lines of reading and enterng the values in stations table variable
    for number, line in enumerate(reading):
        entry = line.split(';')
        stations_table.add((entry[4], entry[17], entry[18]))

# Adding values in the readings table variable
        readings_table.append(
            [number + 1, entry[0], entry[1], entry[2], entry[3], entry[5], entry[6], entry[7], entry[8], entry[9], entry[10],
             entry[11], entry[12], entry[13], entry[14], entry[15], entry[16], entry[19], entry[20], entry[21],
             entry[22], entry[4].strip('\n')])
        print(number + 1)
    connmydb.autocommit = False                  #  group multiple subsequent Statements under the same transaction

# calling cursor to enter data into the tabele created with name 'Schema' in the database
    for row in schema_table:
        mycursor.execute("INSERT INTO `Schema` VALUES(%s, %s, %s, %s)", tuple(row))

# calling cursor to enter data into the tabele created with name 'Stations' in the database
    for row in stations_table:
        mycursor.execute("INSERT INTO `Stations` VALUES(%s, %s, %s)", tuple(row))

# calling cursor to enter data into the tabele created with name 'Readings' in the database
    for row in readings_table:
        mycursor.execute(
            "INSERT INTO `Readings` VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            tuple(row))

# 
    connmydb.commit()          # Confirm the changes made, to the database
    connmydb.close()           # Closing the connection with mysql server

except BaseException as error:                     # exception : will show any error if occured
    print(f"An error occured: {error}")
    sys.exit(1)

# Printing the time taken to execute the code
print('populate.py took ', str(datetime.datetime.now() - start), 'seconds to execute') 