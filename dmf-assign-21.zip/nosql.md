 # Data Management Fundamentals - Assignment Task-5

**Submission   - 20.01.2022   
Professor      - Prakash Chaterjee   
Student name   - Parashkumar Shah    
Nudest ID      - 21051422**     
   
**Database     - MongoDB**   
**Method       - Key-Value Pair**

**<ins>Research and importance of using a NoSQL database<ins>**
    
With the teachings received in your sessions and other self research from web surfing, I have gathered some knowledge of NosQL database and according to the requirement of task-5 I Have selected Mongo-DB as a database have shown my working below.

**<ins>NoSQL Database</ins>**

A mechanism of storing and retrieving the data in means other than tabular relations used in relational data is NoSQL Database. The existence of such databases has been from 1960 but the word "NOSQL" became popular after 2009 used by Carlo Strozzi.   
**source** : *[Wikipedia](https://en.wikipedia.org/wiki/NoSQL)*

**<ins>Importance of using NoSQL Database</ins>**
    
- High Scalability   
NoSQL database built with a masterclass, peer to peer architecture. Just write few lines and new server added to the 
cluster.    

- Flexibility of Schema   
Unlike SQL databases, NoSQL databases do not require any predefined schema to store data.

- Lower Cost   
Capacities can be added by scaling horizontally over cheap,commodity servers, which makes NoSQL databases cheaper than relational databases. 

- Open Source   
Most of the NoSQL databases are open source, meaning companies can use them without any licences needed. 

- Distributed computing   
Relational databases are single location-dependent. NoSQL databases are designed to distribute data globally, thus using multiple cloud/data centers around the globe.

- Normalization not required   
It is needed to divide data into multiple collections and giving reference between those collections. This is not at all required in NoSQL databases.

- Multi-Model   
It does not put any restriction on the type of data to be stores. Used by many developers to handle data of various kinds.


**<ins>The four main types of NoSQL databases</ins>**
    
![four_types_of_nosql_databases](Capture6.png)

    
Image Source :  *[microsoft.com](https://docs.microsoft.com/en-us/dotnet/architecture/cloud-native/relational-vs-nosql-data)*


**<ins>Key-Value Pair model and its benefits</ins>**  
A Key-Value Pair (KVP) is a structure which provides a model to recored data in its key and value format. Where key is an unique identifier for its values stored, which can be any form of data including simple objects like integers, strings or compound objects like images or anything.

<ins>Importance</ins> :-   
1) Simplicity : It is very simple in structure, thus does not require compex tabular structures to store the data.
2) Scalability : It can be store high volume of data.
3) Reliability : Because of its unique key assign feature, it is very reliable in quering.
4) Easy to move : The data can be move easily.
5) Speedy : becuse of its simpe structure it is very fast in operations. 


**<ins>MongoDb</ins>**
    
MongoDB has its origins back from 2007 founded by Dwight Merriman, Eliot Horowitz and Kevin Ryan and the first release was made in 2009. Built on Scale-out architecture, it is a document based database which is highly used by the developers to built applications with evolving data schema. It is written in C++, Python, Javascrit and Go. It has ability to handle high volume data, both vertically and horizontally. It is document-based and works on JSON format according to key-value pair. A vercetile range of industries like gaming, healthcare, finance and retails uses MongoDB for application development.

Source : *[MongoDB website](https://www.mongodb.com/why-use-mongodb)*

**<ins>Features of MongoDB</ins>**   
There is no doubt in believing the fact that MongoDB is most popular non-relation database.      
- Provides better iteration   
To change or add fields in MongoDB is exceptionally very easy. Even Sorting and filtering is very easy.    

- Easy to learn and get started   

- Has got a large community   
With over 210 million downloads 1.5 million university registrations, Companies like Uber, KAVAK, Accenture, Stack, etc uses MongoDB.   

- Multiple Document transaction   
ACID compliance. (Automacity, Consistency, Isolaton and Durability)

- Supports joins in Queries



**<ins>Downloading and setting up MongoDB</ins>**

For downloading MongoDb, I visited *[MondoDB website](https://www.mongodb.com/try/download/community)* .  I downloaded "On Premises" 5.0.5 (current version) for windows platform. I than ran the exe file and simply followed the steps, which enabled me to install MongoDB and MongoDB Compass (its an GUI based application which empowers to connect with the server without running commands). 

**<ins>Steps I followed for Connecting to Mongo database</ins>**

**Step 1**: For checking whether installed drive c > program Files > mognoDB > Server > 5.0.5  *(copy the path)*  
**Step 2**: Reach the directory by <span style="color: red;">type</span> >cd C:\Program Files\MongoDB\Server\5.0 *(paste the path)*                          
**Step 3**: Open command prompt and <span style="color: red;">type</span> mongod to start the demon   
**Step 4**: Drive c > create folder (data) > create a folder (db)   
**Step 5**: Open same command prompt and <span style="color: red;">type</span> mongod to start the demon.   
**Step 6**: Open a new command prompt terminal and <span style="color: red;">type</span> cd C:\Program Files\MongoDB\Server\5.0 *(paste the path)*   
**Step 7**: In the same prompt <span style="color: red;">type</span> mongo


*I then used command prompt terminal to create a database, and populate the date and also run queries. It can also be done from the GUI interface of MongoDB compass.*

**<ins>Steps I followed for creating new database and populate it</ins>**

**Step 1**: In the same prompt <span style="color: red;">type</span> show dbs     (This will show all the default databases)    
**Step 2**: <span style="color: red;">Type</span> use pollution-db     (To create new database)   
**Step 3**: <span style="color: red;">Type</span> db.createCollection("baqd") (to create collection under database)   
    
<span style="color: Green;">*I inserted data from a particular SiteID - 452, location - 'AURN St Pauls'*</span>      
**Step 4**: To populate the database   
<span style="color: red;">Type</span>    
 ```json   
db.baqd.insertMany([{                                         
"Date Time": "2013-08-23T07:00:00+00:00",     
... "NOx": "51.54044",   
... "NO2": "30.50055",   
... "NO": "13.72186",   
... "SiteID": "452",   
... "PM10": "27.8",   
... "NVPM10": "23.2",   
... "VPM10": "4.6",   
... "NVPM2.5": "16.4",   
... "PM2.5": "19.454",   
... "VPM2.5": "2.9",   
... "CO": "NULL",   
... "O3": "20.40603",   
... "SO2": "NULL",   
... "Temperature": "NULL",   
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",   
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... },   
... {   
... "Date Time": "2013-08-23T18:00:00+00:00",   
... "NOx": "46.65544",   
... "NO2": "42.06448",   
... "NO": "2.99414",   
... "SiteID": "452",   
... "PM10": "31.1",   
... "NVPM10": "26.5",   
... "VPM10": "4.6",   
... "NVPM2.5": "19.7",   
... "PM2.5": "24.595",   
... "VPM2.5": "4.7",   
... "CO": "NULL",   
... "O3": "42.30884",   
... "SO2": "NULL",    
... "Temperature": "NULL",    
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",   
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... },   
... {   
... "Date Time": "2013-08-23T22:00:00+00:00",   
... "NOx": "32.00043",   
... "NO2": "28.99493",   
... "NO": "1.96013",   
... "SiteID": "452",   
... "PM10": "32.3",   
... "NVPM10": "20.9",   
... "VPM10": "11.4",    
... "NVPM2.5": "16.2",   
... "PM2.5": "25.603",   
... "VPM2.5": "9.2",   
... "CO": "NULL",   
... "O3": "30.73378",   
... "SO2": "NULL",   
... "Temperature": "NULL",   
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",   
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... },   
... {   
... "Date Time": "2013-08-24T04:00:00+00:00",   
... "NOx": "22.65356",   
... "NO2": "18.31745",   
... "NO": "2.82794",   
... "SiteID": "452",   
... "PM10": "19.5",   
... "NVPM10": "16.1",    
... "VPM10": "3.4",   
... "NVPM2.5": "10.5",   
... "PM2.5": "14.314",   
... "VPM2.5": "3.7",   
... "CO": "NULL",   
... "O3": "36.12217",   
... "SO2": "NULL",   
... "Temperature": "NULL",   
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",   
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... },   
... {   
... "Date Time": "2013-08-24T21:00:00+00:00",   
... "NOx": "18.69469",   
... "NO2": "15.12692",   
... "NO": "2.32684",   
... "SiteID": "452",   
... "PM10": "10.7",   
... "NVPM10": "7.9",   
... "VPM10": "2.8",   
... "NVPM2.5": "4.7",   
... "PM2.5": "7.963",   
... "VPM2.5": "3.2",   
... "CO": "NULL",   
... "O3": "47.99659",   
... "SO2": "NULL",   
... "Temperature": "NULL",    
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",    
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... },   
... {   
... "Date Time": "2013-08-25T02:00:00+00:00",   
... "NOx": "11.07146",   
... "NO2": "8.92325",   
... "NO": "1.40103",   
... "SiteID": "452",   
... "PM10": "9.0",   
... "NVPM10": "6.5",   
... "VPM10": "2.5",   
... "NVPM2.5": "1.3",   
... "PM2.5": "4.234",   
... "VPM2.5": "2.9",   
... "CO": "NULL",   
... "O3": "48.5953",   
... "SO2": "NULL",   
... "Temperature": "NULL",   
... "RH": "NULL",   
... "AirPressure": "NULL",   
... "Location": "AURN St Pauls",   
... "geo_point_2d": "51.4628294172,-2.58454081635",   
... "DateStart": "2006-06-15T00:00:00+00:00",   
... "DateEnd": "NULL",   
... "Current": "True",   
... "InstrumentType": "Continuous (Reference)"   
... }])          
```

**<ins>Command Prompt idle executing the code</ins>**

![Capture](Capture.PNG)


![Capture1](Capture1.PNG)

**<ins>To check the data into collection</ins>**


- <span style="color: red;">Type</span> db.baqd.find().pretty()
    
    <span style="color: red;">Result :</span>   
```
    "_id" : ObjectId   ("61df2715ea6fd1211ffd5431"),   
        "Date Time" : "2013-08-23T07:00:00  +00:00",   
        "NOx" : "51.54044",   
        "NO2" : "30.50055",   
        "NO" : "13.72186",   
        "SiteID" : "452",   
        "PM10" : "27.8",   
        "NVPM10" : "23.2",   
        "VPM10" : "4.6",   
        "NVPM2.5" : "16.4",    
        "PM2.5" : "19.454",   
        "VPM2.5" : "2.9",   
        "CO" : "NULL",   
        "O3" : "20.40603",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}   
{   
        "_id" : ObjectId("61df2715ea6fd1211ffd5432"),   
        "Date Time" : "2013-08-23T18:00:00+00:00",   
        "NOx" : "46.65544",   
        "NO2" : "42.06448",   
        "NO" : "2.99414",   
        "SiteID" : "452",   
        "PM10" : "31.1",   
        "NVPM10" : "26.5",   
        "VPM10" : "4.6",   
        "NVPM2.5" : "19.7",   
        "PM2.5" : "24.595",     
        "VPM2.5" : "4.7",   
        "CO" : "NULL",   
        "O3" : "42.30884",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}   
{   
        "_id" : ObjectId("61df2715ea6fd1211ffd5433"),   
        "Date Time" : "2013-08-23T22:00:00+00:00",   
        "NOx" : "32.00043",    
        "NO2" : "28.99493",   
        "NO" : "1.96013",   
        "SiteID" : "452",    
        "PM10" : "32.3",   
        "NVPM10" : "20.9",   
        "VPM10" : "11.4",    
        "NVPM2.5" : "16.2",   
        "PM2.5" : "25.603",   
        "VPM2.5" : "9.2",    
        "CO" : "NULL",    
        "O3" : "30.73378",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}   
{   
        "_id" : ObjectId("61df2715ea6fd1211ffd5434"),   
        "Date Time" : "2013-08-24T04:00:00+00:00",   
        "NOx" : "22.65356",   
        "NO2" : "18.31745",   
        "NO" : "2.82794",   
        "SiteID" : "452",   
        "PM10" : "19.5",   
        "NVPM10" : "16.1",   
        "VPM10" : "3.4",   
        "NVPM2.5" : "10.5",   
        "PM2.5" : "14.314",   
        "VPM2.5" : "3.7",   
        "CO" : "NULL",   
        "O3" : "36.12217",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}   
{   
        "_id" : ObjectId("61df2715ea6fd1211ffd5435"),   
        "Date Time" : "2013-08-24T21:00:00+00:00",   
        "NOx" : "18.69469",   
        "NO2" : "15.12692",   
        "NO" : "2.32684",   
        "SiteID" : "452",    
        "PM10" : "10.7",   
        "NVPM10" : "7.9",   
        "VPM10" : "2.8",    
        "NVPM2.5" : "4.7",    
        "PM2.5" : "7.963",   
        "VPM2.5" : "3.2",   
        "CO" : "NULL",   
        "O3" : "47.99659",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}   
{   
        "_id" : ObjectId("61df2715ea6fd1211ffd5436"),   
        "Date Time" : "2013-08-25T02:00:00+00:00",   
        "NOx" : "11.07146",   
        "NO2" : "8.92325",   
        "NO" : "1.40103",   
        "SiteID" : "452",   
        "PM10" : "9.0",   
        "NVPM10" : "6.5",   
        "VPM10" : "2.5",   
        "NVPM2.5" : "1.3",   
        "PM2.5" : "4.234",   
        "VPM2.5" : "2.9",   
        "CO" : "NULL",   
        "O3" : "48.5953",   
        "SO2" : "NULL",   
        "Temperature" : "NULL",   
        "RH" : "NULL",   
        "AirPressure" : "NULL",   
        "Location" : "AURN St Pauls",   
        "geo_point_2d" : "51.4628294172,-2.58454081635",   
        "DateStart" : "2006-06-15T00:00:00+00:00",   
        "DateEnd" : "NULL",   
        "Current" : "True",   
        "InstrumentType" : "Continuous (Reference)"   
}  
``` 


**<ins>To find the total number of documents</ins>**

- <span style="color: red;">Type</span> db.baqd.aggregate([{$group :{_id:"SiteID", total:{$sum: 1}}}])

![Capture2](Capture2.PNG)

**<ins>To find the statistics of database</ins>**

- <span style="color: red;">Type</span> db.stats()

![Capture3.png](Capture3.PNG)

**<ins>The view can be changed from document type to tabular format with row and columns with the help of highlighted button.</ins>**

![Capture4.PNG](Capture4.PNG)

**<ins>I have also tried to run some queries from MongoDB Compass</ins>**

![Capture5.png](Capture5.png)

**<ins>Some more learnings</ins>**   
I found that there are several ways in MongoDb to perform the same task, For an example To create a Database and collection, the simplest way is to do it from MongoDb compass. Than, We can also populate database by GUI in compass using JSON as well as XML files.   
We can also use MongoDB cloud, which gives options to use Google Cloud, AWS and Azure. It can be accessed by MongoDB Atlas.   
Because of this task I got a chance to learn MongoDB(a widely recognized software in the industry). There is still lot more to learn and many things to explore here.