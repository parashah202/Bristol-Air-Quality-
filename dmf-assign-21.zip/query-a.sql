SELECT Readings.DateTime AS DateTime,Readings.NOx AS Highest_Recorded_NOx ,Stations.Location 
FROM Readings,Stations 
WHERE NOx=(SELECT MAX(`NOx`) 
FROM Readings 
WHERE year(`DateTime`)="2019") AND Readings.SiteID = Stations.SiteID