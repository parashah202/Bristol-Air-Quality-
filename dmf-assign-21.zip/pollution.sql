-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2022 at 11:30 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pollution-db`
--

-- --------------------------------------------------------

--
-- Table structure for table `readings`
--

CREATE TABLE `readings` (
  `ReadingID` int(11) NOT NULL,
  `DateTime` datetime NOT NULL COMMENT 'Date and time of measurement',
  `NOx` float DEFAULT NULL COMMENT 'Concentration of oxides of nitrogen',
  `NO2` float DEFAULT NULL COMMENT 'Concentration of nitrogen dioxide',
  `NO` float DEFAULT NULL COMMENT 'Concentration of nitric oxide',
  `PM10` float DEFAULT NULL COMMENT 'Concentration of particulate matter <10 micron diameter',
  `NVPM10` float DEFAULT NULL COMMENT 'Concentration of non - volatile particulate matter <10 micron diameter',
  `VPM10` float DEFAULT NULL COMMENT 'Concentration of volatile particulate matter <10 micron diameter',
  `NVPM2.5` float DEFAULT NULL COMMENT 'Concentration of non volatile particulate matter <2.5 micron diameter',
  `PM2.5` float DEFAULT NULL COMMENT 'Concentration of particulate matter <2.5 micron diameter',
  `VPM2.5` float DEFAULT NULL COMMENT 'Concentration of volatile particulate matter <2.5 micron diameter',
  `CO` float DEFAULT NULL COMMENT 'Concentration of carbon monoxide',
  `O3` float DEFAULT NULL COMMENT 'Concentration of ozone',
  `SO2` float DEFAULT NULL COMMENT 'Concentration of sulphur dioxide',
  `Temperature` double DEFAULT NULL COMMENT 'Air temperature',
  `RH` int(11) DEFAULT NULL COMMENT '	Relative Humidity',
  `AirPressure` int(11) DEFAULT NULL COMMENT 'Air Pressure',
  `DateStart` datetime DEFAULT NULL COMMENT '	The date monitoring started',
  `DateEnd` datetime DEFAULT NULL COMMENT 'The date monitoring ended',
  `Current` text DEFAULT NULL COMMENT 'Is the monitor currently operating',
  `InstrumentType` varchar(32) DEFAULT NULL COMMENT 'Classification of the instrument',
  `SiteID` int(11) NOT NULL COMMENT 'Site ID for the station'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schema`
--

CREATE TABLE `schema` (
  `SchemaID` int(11) NOT NULL,
  `Measure` varchar(32) NOT NULL,
  `Description` varchar(64) NOT NULL,
  `Unit` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stations`
--

CREATE TABLE `stations` (
  `SiteID` int(11) NOT NULL COMMENT 'Site ID for the station',
  `Location` varchar(48) NOT NULL COMMENT 'Text description of location',
  `geo_point_2d` varchar(48) NOT NULL COMMENT 'Latitude and longitude'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `readings`
--
ALTER TABLE `readings`
  ADD PRIMARY KEY (`ReadingID`),
  ADD KEY `stationid` (`SiteID`);

--
-- Indexes for table `schema`
--
ALTER TABLE `schema`
  ADD PRIMARY KEY (`SchemaID`);

--
-- Indexes for table `stations`
--
ALTER TABLE `stations`
  ADD PRIMARY KEY (`SiteID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `readings`
--
ALTER TABLE `readings`
  ADD CONSTRAINT `stationid` FOREIGN KEY (`siteid`) REFERENCES `stations` (`siteid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
