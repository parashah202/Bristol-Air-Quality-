# Data Management Fundamentals - Task-6 : Reflective Report
   
**Submission   - 20.01.2022   
Professor      - Prakash Chaterjee   
Student name   - Parashkumar Shah    
Student ID     - 21051422**

*I am very new to programming, other than having knowledge from achieving Google Analytics Certificate, I was deprived in some very crucial aspects of Data Science. The whole module had been well structured and I learned many new concepts, skills and technologies from week 1 till I finally wrote the last part of this assignment.* 

**<ins>Learning outcomes from this assignment</ins>**
- Good learning in Python programming with a better understanding of modules like csv, Datetime, pandas, mariadb, using SQL in Python, etc and a much clearer logic building.
- Precise knowledge of relational data base, normalization, using SQL server with MySQL workbench and PHP my admin, ER modelling and establishing relations, and designing SQL queries. 
- Exposure and understanding of NoSQL databases,  different types and using Key-Value Pair model to learn MongoDB. In depth learning from installing, establishing connection with server and querying from Command Prompt and MongoDB Compass.
- Using Markdown File format for reporting. Inserting images, links, and using some key functions to enhance documenting.
- A clear flow of Data from csv file to pushing data into tables and querying for desired outcomes and finally reading the data to take out insights. 

**<ins>Problems encountered and solutions found</ins>**
- I struggled a lot in python coding, in the first task I first tried using pandas, but it was creating a data frame, and a well structured excel file, which was creating some problem in reading in all later files. Finally i used csv to resolve it.
- In second task, creating a ER diagram was easy, as I had practiced it a lot in workshops. I used MySQL Workbench for that, but when I tried to forward engineer it to create tables, it was asking for connecting to server, I  tried so much but couldn't do it. Thus finally,I manually created tables using PHPmyadmin and than exported a sql script.
- Third task was the most difficult one for me, firstly I struggled establishing connecting than after exploring Google, I was able to do it. I also referred Google searches for populating data from clean.csv to the database. Mostly i followed [geeksforgeeks](https://www.geeksforgeeks.org/python-programming-language/?ref=shm), whenever I was stuck on something.
- Fourth task was not so difficult. It went pretty smooth.
- Installing MOngoDB was easy, but for establishing connection and getting knowledge about MongoDb I followed a YouTube videos : [video1](https://youtu.be/H-MWUJNXicw) and [video2](https://youtu.be/ocTPS4QH8sM). For better understanding of MongoDB compass I watched these YouTube videos : [video3](https://www.youtube.com/watch?v=ydXCcLAi5aU&t) and [video4](www.youtube.com/watch?v=npZiC97mQrY&t). 
- For Making a report for Task-5 and Task-6 in markdown, I followed the following website [markdownguide](https://www.markdownguide.org/basic-syntax/). I also had a problem in inserted images in markdown file, that were not displaying in the HTML view. For this many some other small problems faces I got a quick feedback and solution from our Professor - Mr. Prakash Chatterjee. 

**<ins>To visualize this data set</ins>**   
Python has some wonderful modules and that has good visualization features.   
1. Looking at the data set it has precise locations with longitude and latitude for all 14 stations. Map visualizations can me made using libraries "Geopandas" and "Geoplot".
2. Also, change in air pressure and other air particles from the recordings take from over time to time can me studies by using scatter plots, for which plt.scatter() can be very helpful from matplotlib module.   
3. Can use pie chart to find the highest number of air particles present in the air at any given point of time and discover solutions for cleaning those, seaborn library can be very helpful in this. 
4. Temperature and humidity has a correlation, we can find their correlation coefficient in different stations using line chart. Matplotlib can be very handy in this plotting.

These are some possible visualizations we can create out of this data.