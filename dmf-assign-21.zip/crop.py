# Opening csv Data file as baqd in read mode and opening new fil crop.csv in write mode as crop.
with open("bristol-air-quality-data.csv", "r") as baqd, open("crop.csv", "w") as crop: 

    # Read from baqdand write to crop
    crop.write(baqd.readline()) 

    # Iterating through all rows in baqd
    for rows in baqd.readlines(): 

        # Checking by conditioning that first four characters are numberic and greater than year 2009
        if rows[0:4].isnumeric() and int(rows[0:4]) > 2009: 

            # Write only those data which satisfy the above condition to crop.csv file
            crop.write(rows)  