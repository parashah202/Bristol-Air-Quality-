# Importing necessary modules
import csv
import datetime

# Setting up time before the script starts to calculate time
start = datetime.datetime.now()

# read crop.csv file with DictReader function and load it to python variable to be used along the script
data = csv.DictReader(open("crop.csv"), delimiter = ";")

# prepare a stations dictionary 
stations = {
            '188': 'AURN Bristol Centre',
            '203': 'Brislington Depot',
            '206': 'Rupert Street',
            '209': 'IKEA M32',
            '213': 'Old Market',
            '215': 'Parson Street School',
            '228': 'Temple Meads Station',
            '270': 'Wells Road',
            '271': 'Trailer Portway P&R',
            '375': 'Newfoundland Road Police Station',
            '395': "Shiner's Garage",
            '452': 'AURN St Pauls',
            '447': 'Bath Road',
            '459': 'Cheltenham Road \ Station Road',
            '463': 'Fishponds Road',
            '481': 'CREATE Centre Roof',
            '500': 'Temple Way',
            '501': 'Colston Avenue',
}

# Declare variables with some initial values
rcount = 1
dcount = 0

# Opening new file in a write mode
with open("clean.csv", "w", newline='') as clean:

    # Writing the column heads in the new file
    writer = csv.DictWriter(clean, delimiter=';', fieldnames=data.fieldnames)
    writer.writeheader()

    # Print out and check what is inside of this
    print(stations.items())
    
    # Iterating through data to filter and write the required readings in new file 
    for row in data:
        # If SiteID and Location are not in stations.items, we don't take that record(remove)
        if(not(row['SiteID'], row['Location']) in stations.items()):
            dcount += 1
        else:
            rcount += 1
            writer.writerow(row)


print(str(dcount) + ' Mismatches removed.')          # Mismatched lines that were removed
print(str(rcount) + ' lines written to clean.csv')   # Lines that were written to the new file

# Finding out the total time it took to run this script
print('clean.py took ' + str(datetime.datetime.now() - start) + ' seconds to execute.')
