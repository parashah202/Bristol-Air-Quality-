# Importing necessary modules
import csv

# Opening clean.csv file in read mode 
with open('clean.csv','r')as cleaned:
    reader=csv.reader(cleaned, delimiter=';')

    # Opening a new sql file in write mode
    with open('insert-100.sql','w')as sql_file:

        lines = 0               # Setting up Variable row to 0 for iterating and writing data
        starting = 0            # Setting up variable starting to 0 for iterating and writing data 
        top_100 = 100           # Setting up variable top_100 to 100 for iterating and writing, this will allow us to insert first 100 records

        # Iterating rows in reader 
        for row in reader:
            if starting <= top_100:
                if row==0:

                    # Printing headers
                    header=("Date Time,NOx,NO2,NO,PM10,NVPM10,VPM10,NVPM2.5,PM2.5,VPM2.5,CO,O3,SO2,Temperature,RH,AirPressure,DateStart,DateEnd,Current,InstrumentType,SiteID")
                    sql_file.write(header+"\n")
                else:

                    # Writing data in sql file
                    data=(row[0],row[1] if row[1]!="" else None,row[2] if row[2]!="" else None,row[3] if row[3]!="" else None,row[5] if row[5]!="" else None,row[6] if row[6]!="" else None,row[7] if row[7]!="" else None,row[8] if row[8]!="" else None,row[9] if row[9]!="" else None,row[10] if row[10]!="" else None,row[11] if row[11]!="" else None,row[12] if row[12]!="" else None,row[13] if row[13]!="" else None,row[14] if row[14]!="" else None,row[15] if row[15]!="" else None,row[16] if row[16]!="" else None,row[19] if row[19]!="" else None,row[20] if row[20]!="" else None,row[21],row[22],row[4] if row[4]!="" else None)
                    sql_file.write(str(data)+"\n")
                lines += 1
            starting += 1
